import { _ as readTask, x as writeTask } from "./index-Ci0c0wtC-Bx9PS6vi.js";
import { a as componentOnReady } from "./helpers-D3HlaZqB-CR9sKJrO.js";
import { i as findClosestIonContent, p as scrollToTop } from "./index-BBArCvE7-zN5NUlTG.js";
//#region node_modules/@ionic/core/dist/esm/status-tap-D3yqZrEP.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var startStatusTap = () => {
	const win = window;
	win.addEventListener("statusTap", () => {
		readTask(() => {
			const width = win.innerWidth;
			const height = win.innerHeight;
			const el = document.elementFromPoint(width / 2, height / 2);
			if (!el) return;
			const contentEl = findClosestIonContent(el);
			if (contentEl) new Promise((resolve) => componentOnReady(contentEl, resolve)).then(() => {
				writeTask(async () => {
					/**
					* If scrolling and user taps status bar,
					* only calling scrollToTop is not enough
					* as engines like WebKit will jump the
					* scroll position back down and complete
					* any in-progress momentum scrolling.
					*/
					contentEl.style.setProperty("--overflow", "hidden");
					await scrollToTop(contentEl, 300);
					contentEl.style.removeProperty("--overflow");
				});
			});
		});
	});
};
//#endregion
export { startStatusTap };
