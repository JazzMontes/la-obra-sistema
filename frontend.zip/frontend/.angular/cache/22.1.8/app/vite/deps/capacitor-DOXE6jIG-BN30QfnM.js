import { w as win } from "./helpers-D3HlaZqB-CR9sKJrO.js";
//#region node_modules/@ionic/core/dist/esm/capacitor-DOXE6jIG.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var getCapacitor = () => {
	if (win !== void 0) return win.Capacitor;
};
//#endregion
export { getCapacitor as t };
