import { t as isRTL } from "./dir-Dojwmvde-JWsS7_L7.js";
import { w as win, y as raf } from "./helpers-D3HlaZqB-CR9sKJrO.js";
//#region node_modules/@ionic/core/dist/esm/slot-mutation-controller-B_Gyzsmn.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
/**
* A utility to calculate the size of an outline notch
* width relative to the content passed. This is used in
* components such as `ion-select` with `fill="outline"`
* where we need to pass slotted HTML content. This is not
* needed when rendering plaintext content because we can
* render the plaintext again hidden with `opacity: 0` inside
* of the notch. As a result we can rely on the intrinsic size
* of the element to correctly compute the notch width. We
* cannot do this with slotted content because we cannot project
* it into 2 places at once.
*
* @internal
* @param el: The host element
* @param getNotchSpacerEl: A function that returns a reference to the notch spacer element inside of the component template.
* @param getLabelSlot: A function that returns a reference to the slotted content.
*/
var createNotchController = (el, getNotchSpacerEl, getLabelSlot) => {
	let notchVisibilityIO;
	const needsExplicitNotchWidth = () => {
		if (getNotchSpacerEl() === void 0 || el.label !== void 0 || getLabelSlot() === null) return false;
		return true;
	};
	const calculateNotchWidth = () => {
		if (needsExplicitNotchWidth())
 /**
		* Run this the frame after
		* the browser has re-painted the host element.
		* Otherwise, the label element may have a width
		* of 0 and the IntersectionObserver will be used.
		*/
		raf(() => {
			setNotchWidth();
		});
	};
	/**
	* When using a label prop we can render
	* the label value inside of the notch and
	* let the browser calculate the size of the notch.
	* However, we cannot render the label slot in multiple
	* places so we need to manually calculate the notch dimension
	* based on the size of the slotted content.
	*
	* This function should only be used to set the notch width
	* on slotted label content. The notch width for label prop
	* content is automatically calculated based on the
	* intrinsic size of the label text.
	*/
	const setNotchWidth = () => {
		const notchSpacerEl = getNotchSpacerEl();
		if (notchSpacerEl === void 0) return;
		if (!needsExplicitNotchWidth()) {
			notchSpacerEl.style.removeProperty("width");
			return;
		}
		const width = getLabelSlot().scrollWidth;
		if (width === 0 && notchSpacerEl.offsetParent === null && win !== void 0 && "IntersectionObserver" in win) {
			/**
			* If there is an IO already attached
			* then that will update the notch
			* once the element becomes visible.
			* As a result, there is no need to create
			* another one.
			*/
			if (notchVisibilityIO !== void 0) return;
			const io = notchVisibilityIO = new IntersectionObserver(
				(ev) => {
					/**
					* If the element is visible then we
					* can try setting the notch width again.
					*/
					if (ev[0].intersectionRatio === 1) {
						setNotchWidth();
						io.disconnect();
						notchVisibilityIO = void 0;
					}
				},
				/**
				* Set the root to be the host element
				* This causes the IO callback
				* to be fired in WebKit as soon as the element
				* is visible. If we used the default root value
				* then WebKit would only fire the IO callback
				* after any animations (such as a modal transition)
				* finished, and there would potentially be a flicker.
				*/
				{
					threshold: .01,
					root: el
				}
			);
			io.observe(notchSpacerEl);
			return;
		}
		/**
		* If the element is visible then we can set the notch width.
		* The notch is only visible when the label is scaled,
		* which is why we multiply the width by 0.75 as this is
		* the same amount the label element is scaled by in the host CSS.
		* (See $form-control-label-stacked-scale in ionic.globals.scss).
		*/
		notchSpacerEl.style.setProperty("width", `${width * .75}px`);
	};
	const destroy = () => {
		if (notchVisibilityIO) {
			notchVisibilityIO.disconnect();
			notchVisibilityIO = void 0;
		}
	};
	return {
		calculateNotchWidth,
		destroy
	};
};
/**
* Applied to the host while the label is being repositioned. The
* component stylesheets style this class, so it must stay in sync with
* the `skip-label-transition` selector in those files. Renaming it here
* requires renaming it there too.
*/
var SKIP_LABEL_TRANSITION_CLASS = "skip-label-transition";
/**
* Set on the host as an inline style. The component stylesheets declare
* this property and read it with `var()`, so it must stay in sync with
* the `--internal-start-container-adjustment` references in those files.
* Renaming it here requires renaming it there too.
*/
var START_CONTAINER_ADJUSTMENT_VAR = "--internal-start-container-adjustment";
/**
* A utility to measure and update the start container width adjustment
* for form components (input, textarea, select) with `fill="outline"`.
* This adjustment compensates for the start container width when
* positioning floating/stacked labels within the outline border.
*
* Measurement is deferred with raf() to avoid forcing layout during
* component updates, and a ResizeObserver watches for dynamic width
* changes (e.g., when web fonts load or async content changes).
*
* @internal
* @param el - The host element (ion-input, ion-textarea, or ion-select).
* @param getStartContainer - A callback that returns the start container element.
* @param shouldApplyAdjustment - A callback that determines whether the adjustment should be applied.
*/
var createStartContainerController = (el, getStartContainer, shouldApplyAdjustment) => {
	let resizeObserver;
	let observedContainer;
	let measurementRaf;
	let transitionRaf;
	let appliedAdjustment;
	const calculateAdjustment = () => {
		const startSlot = getStartContainer();
		if (!startSlot || !shouldApplyAdjustment()) return "";
		const startContainerWidth = startSlot.getBoundingClientRect().width;
		const roundedWidth = Math.round(startContainerWidth * 10) / 10;
		const sign = isRTL(el) ? "" : "-";
		return roundedWidth ? `${sign}${roundedWidth}px` : "0px";
	};
	const scheduleAdjustmentUpdate = () => {
		if (measurementRaf !== void 0) return;
		measurementRaf = raf(() => {
			measurementRaf = void 0;
			const adjustment = calculateAdjustment();
			if (adjustment !== appliedAdjustment) {
				if (transitionRaf !== void 0) cancelAnimationFrame(transitionRaf);
				el.classList.add(SKIP_LABEL_TRANSITION_CLASS);
				el.style.setProperty(START_CONTAINER_ADJUSTMENT_VAR, adjustment);
				appliedAdjustment = adjustment;
				transitionRaf = raf(() => {
					transitionRaf = void 0;
					el.classList.remove(SKIP_LABEL_TRANSITION_CLASS);
				});
			}
			setupResizeObserver();
		});
	};
	const disconnectResizeObserver = () => {
		if (resizeObserver) {
			resizeObserver.disconnect();
			resizeObserver = void 0;
			observedContainer = void 0;
		}
	};
	const setupResizeObserver = () => {
		const startSlot = getStartContainer();
		if (!startSlot || !shouldApplyAdjustment()) {
			disconnectResizeObserver();
			return;
		}
		if (typeof ResizeObserver !== "function" || resizeObserver && observedContainer === startSlot) return;
		disconnectResizeObserver();
		resizeObserver = new ResizeObserver(() => {
			scheduleAdjustmentUpdate();
		});
		observedContainer = startSlot;
		resizeObserver.observe(startSlot);
	};
	const calculateStartContainerWidth = () => {
		scheduleAdjustmentUpdate();
	};
	const destroy = () => {
		disconnectResizeObserver();
		if (measurementRaf !== void 0) {
			cancelAnimationFrame(measurementRaf);
			measurementRaf = void 0;
		}
		if (transitionRaf !== void 0) {
			cancelAnimationFrame(transitionRaf);
			transitionRaf = void 0;
			el.classList.remove(SKIP_LABEL_TRANSITION_CLASS);
		}
		appliedAdjustment = void 0;
	};
	return {
		calculateStartContainerWidth,
		destroy
	};
};
/**
* The content slotted into a form control's start or end slot that a click
* started on, or `null` when the click did not start on slotted content.
*
* The slotted element is compared against the host in case the form control
* itself is slotted into, for example, an item. Without that check a control
* carrying slot="start"/"end" would treat every click on itself as a slotted
* click.
*/
var getSlottedClickContent = (ev, el) => {
	const slotted = ev.target.closest("[slot=\"start\"], [slot=\"end\"]");
	return slotted !== null && slotted !== el && el.contains(slotted) ? slotted : null;
};
/**
* Whether a click started on content slotted into a form control's start or
* end slot.
*/
var isSlottedClick = (ev, el) => getSlottedClickContent(ev, el) !== null;
/**
* A utility for form components that wrap their content in a <label>, such as
* ion-input, ion-textarea and ion-select.
*
* Clicking slotted content also clicks that label, and the browser follows it
* with a click on the label's control. That second click would be emitted from
* the host as a duplicate, so the slotted click is remembered and the click
* that follows it is suppressed.
*
* Browsers skip the forwarding when the click lands on interactive content,
* such as a slotted button, so the slotted click is remembered for a frame
* rather than until a forwarded click that may never arrive.
*
* @internal
* @param el - The host element.
* @param getNativeInput - A callback returning the native form control the
* label points at, for components that have one. Those components emit the
* click from the host rather than the control, so the control's click is
* always stopped and re-dispatched from the host. Omit it for components whose
* label has no `for` attribute, such as ion-select, where the browser forwards
* to an internal control that already re-bubbles targeting the host.
*/
var createClickController = (el, getNativeInput) => {
	let hasSlottedClick = false;
	const handleClickCapture = (ev) => {
		if (isSlottedClick(ev, el)) {
			hasSlottedClick = true;
			raf(() => hasSlottedClick = false);
			return;
		}
		if (getNativeInput === void 0) {
			if (hasSlottedClick) {
				ev.stopPropagation();
				hasSlottedClick = false;
			}
			return;
		}
		const nativeInput = getNativeInput();
		if (nativeInput !== void 0 && ev.target === nativeInput) {
			ev.stopPropagation();
			if (!hasSlottedClick) el.click();
			hasSlottedClick = false;
		}
	};
	return { handleClickCapture };
};
/**
* Used to update a scoped component that uses emulated slots. This fires when
* content is passed into the slot or when the content inside of a slot changes.
* This is not needed for components using native slots in the Shadow DOM.
* @internal
* @param el The host element to observe
* @param slotName mutationCallback will fire when nodes on these slot(s) change
* @param mutationCallback The callback to fire whenever the slotted content changes
*/
var createSlotMutationController = (el, slotName, mutationCallback) => {
	let hostMutationObserver;
	let slottedContentMutationObserver;
	if (win !== void 0 && "MutationObserver" in win) {
		const slots = Array.isArray(slotName) ? slotName : [slotName];
		hostMutationObserver = new MutationObserver((entries) => {
			for (const entry of entries) for (const node of entry.addedNodes)
 /**
			* Check to see if the added node
			*  is our slotted content.
			*/
			if (node.nodeType === Node.ELEMENT_NODE && slots.includes(node.slot)) {
				/**
				* If so, we want to watch the slotted
				* content itself for changes. This lets us
				* detect when content inside of the slot changes.
				*/
				mutationCallback();
				/**
				* Adding the listener in an raf
				* waits until Stencil moves the slotted element
				* into the correct place in the event that
				* slotted content is being added.
				*/
				raf(() => watchForSlotChange(node));
				return;
			}
		});
		hostMutationObserver.observe(el, {
			childList: true,
			/**
			* This fixes an issue with the `ion-input` and
			* `ion-textarea` not re-rendering in some cases
			* when using the label slot functionality.
			*
			* HTML element patches in Stencil that are enabled
			* by the `experimentalSlotFixes` flag in Stencil v4
			* result in DOM manipulations that won't trigger
			* the current mutation observer configuration and
			* callback.
			*/
			subtree: true
		});
	}
	/**
	* Listen for changes inside of the slotted content.
	* We can listen for subtree changes here to be
	* informed of text within the slotted content
	* changing. Doing this on the host is possible
	* but it is much more expensive to do because
	* it also listens for changes to the internals
	* of the component.
	*/
	const watchForSlotChange = (slottedEl) => {
		if (slottedContentMutationObserver) {
			slottedContentMutationObserver.disconnect();
			slottedContentMutationObserver = void 0;
		}
		slottedContentMutationObserver = new MutationObserver((entries) => {
			mutationCallback();
			for (const entry of entries) for (const node of entry.removedNodes)
 /**
			* If the element was removed then we
			* need to destroy the MutationObserver
			* so the element can be garbage collected.
			*/
			if (node.nodeType === Node.ELEMENT_NODE && node.slot === slotName) destroySlottedContentObserver();
		});
		/**
		* Listen for changes inside of the element
		* as well as anything deep in the tree.
		* We listen on the parentElement so that we can
		* detect when slotted element itself is removed.
		*/
		slottedContentMutationObserver.observe(slottedEl.parentElement ?? slottedEl, {
			subtree: true,
			childList: true
		});
	};
	const destroy = () => {
		if (hostMutationObserver) {
			hostMutationObserver.disconnect();
			hostMutationObserver = void 0;
		}
		destroySlottedContentObserver();
	};
	const destroySlottedContentObserver = () => {
		if (slottedContentMutationObserver) {
			slottedContentMutationObserver.disconnect();
			slottedContentMutationObserver = void 0;
		}
	};
	return { destroy };
};
//#endregion
export { getSlottedClickContent as a, createStartContainerController as i, createNotchController as n, createSlotMutationController as r, createClickController as t };
