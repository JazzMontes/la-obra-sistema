<?php
// Calcula los indicadores de mermas y pérdidas.
require_once __DIR__ . '/common.php';
method('GET');
user(true);
$d = wasteDates(['date_from', 'date_to']);
wasteRange($d['date_from'], $d['date_to']);
try {
    $w = wasteSummary($d['date_from'], $d['date_to']);
    // Misma definición de venta confirmada/pagada que reports/common.php.
    $sales = record("SELECT COALESCE(SUM(o.total),0) AS total FROM orders o WHERE o.order_status='confirmed' AND o.payment_status='paid' AND EXISTS(SELECT 1 FROM payments pay WHERE pay.order_id=o.id AND pay.paid_at>=? AND pay.paid_at<DATE_ADD(?,INTERVAL 1 DAY))", [$d['date_from'], $d['date_to']]);
    $purchases = record('SELECT COALESCE(SUM(total),0) AS total FROM purchases WHERE purchase_date BETWEEN ? AND ?', [$d['date_from'], $d['date_to']]);
    $loss = (float)$w['estimated_loss'];
    $revenue = (float)$sales['total'];
    $purchased = (float)$purchases['total'];

// Enviar respuesta
    out(200, 'Indicadores consultados', ['waste' => $w, 'sales_total' => $revenue, 'purchases_total' => $purchased, 'loss_as_percent_of_sales' => $revenue > 0 ? round($loss / $revenue * 100, 2) : null, 'loss_as_percent_of_purchases' => $purchased > 0 ? round($loss / $purchased * 100, 2) : null, 'cost_basis' => 'purchases_total es gasto en compras del periodo, no costo de ventas ni consumo real', 'note' => 'Los porcentajes se basan en pérdidas con costo calculable; los demás registros se cuentan por separado']);
} catch (Throwable $e) {
    failure($e);
}
