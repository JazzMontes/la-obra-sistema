<?php
// Consulta el listado de mermas y pérdidas.
require_once __DIR__ . '/common.php';
method('GET');
$u = user(false);
$where = [];
$params = [];
wasteFilter($where, $params);
// Igual que ventas/gastos: empleado ve solamente sus registros de hoy.
if ($u['role'] === 'employee') {
    $where[] = 'w.user_id=?';
    $params[] = $u['id'];
    $where[] = 'w.waste_date=CURDATE()';
}

// Consultar o preparar datos
$sql = wasteSelect() . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY w.waste_date DESC,w.id DESC';
try {

// Enviar respuesta
    out(200, 'Mermas consultadas', ['scope' => $u['role'] === 'admin' ? 'all' : 'today_own', 'waste_records' => rows($sql, $params)]);
} catch (Throwable $e) {
    failure($e);
}
