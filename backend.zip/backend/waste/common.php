<?php
// Reúne funciones compartidas de mermas y pérdidas.
require_once __DIR__.'/../config/service_helpers.php';
function wasteDates($keys) {
    $v=[];
    foreach($keys as $k){$v[$k]=dateval($_GET[$k]??null);}
    return $v;
}
function wasteRange($from,$to){if($from>$to)out(422,'El inicio no puede superar el final');}
function wasteFilter(&$where,&$params,$alias='w'){
    foreach(['date_from'=>'>=','date_to'=>'<='] as $key=>$op){if(isset($_GET[$key])&&$_GET[$key]!==''){$where[]="$alias.waste_date $op ?";$params[]=dateval($_GET[$key]);}}
    if(isset($_GET['date_from'],$_GET['date_to'])&&$_GET['date_from']!==''&&$_GET['date_to']!==''&&$_GET['date_from']>$_GET['date_to'])out(422,'Rango de fechas inválido');
    if(isset($_GET['affected_type'])&&$_GET['affected_type']!==''){
        if(!in_array($_GET['affected_type'],['input','product','preparation'],true))out(422,'Tipo inválido');
        $where[]="$alias.affected_type=?";$params[]=$_GET['affected_type'];
    }
    if(isset($_GET['classification'])&&$_GET['classification']!==''){
        if(!is_string($_GET['classification'])||mb_strlen($_GET['classification'])>100)out(422,'Clasificación inválida');
        $where[]="$alias.classification=?";$params[]=$_GET['classification'];
    }
}
function wasteSelect(){return "SELECT w.*,COALESCE(i.name,p.name) AS affected_name,CASE WHEN w.affected_type='input' THEN i.unit ELSE NULL END AS affected_unit,u.name AS user_name FROM waste_records w LEFT JOIN inputs i ON i.id=w.input_id LEFT JOIN products p ON p.id=w.product_id JOIN users u ON u.id=w.user_id";}
function wasteOne($id){return record(wasteSelect().' WHERE w.id=?',[$id]);}
function wasteCostInput($id){
    // Última compra registrada del insumo, sin alterar el historial de compras.
    $r=record('SELECT pi.unit_cost FROM purchase_items pi JOIN purchases p ON p.id=pi.purchase_id WHERE pi.input_id=? ORDER BY p.purchase_date DESC,p.id DESC,pi.id DESC LIMIT 1',[$id]);
    return $r===false?null:round((float)$r['unit_cost'],4);
}
function wasteUnitCost($type,$id){
    if($type==='input')return wasteCostInput($id);
    // Solo se calcula un producto si su receta está completa y TODOS los insumos tienen costo.
    if($type==='product'){
        $parts=rows('SELECT input_id,quantity FROM recipes WHERE product_id=?',[$id]);
        if(!$parts)return null;
        $sum=0;
        foreach($parts as $part){$c=wasteCostInput((int)$part['input_id']);if($c===null)return null;$sum+=(float)$part['quantity']*$c;}
        return round($sum,4);
    }
    return null;
}
function wasteAmount($v){
    if(!is_scalar($v)||!is_numeric($v)||!is_finite((float)$v)||(float)$v<=0||round((float)$v,3)!=(float)$v||(float)$v>999999999.999)out(422,'Cantidad inválida');
    return number_format((float)$v,3,'.','');
}
function wasteSummary($from,$to){
    return record("SELECT COUNT(*) AS records,COALESCE(SUM(CASE WHEN cost_status='calculated' THEN estimated_total_cost ELSE 0 END),0) AS estimated_loss, SUM(CASE WHEN cost_status='unavailable' THEN 1 ELSE 0 END) AS without_cost FROM waste_records WHERE waste_date BETWEEN ? AND ?",[$from,$to]);
}
