<?php
// Compara los periodos de mermas y pérdidas.
require_once __DIR__ . '/common.php';
method('GET');
user(true);
$d = wasteDates(['period1_start', 'period1_end', 'period2_start', 'period2_end']);
wasteRange($d['period1_start'], $d['period1_end']);
wasteRange($d['period2_start'], $d['period2_end']);
try {
    $a = wasteSummary($d['period1_start'], $d['period1_end']);
    $b = wasteSummary($d['period2_start'], $d['period2_end']);
    $diff = round((float)$b['estimated_loss'] - (float)$a['estimated_loss'], 2);
    $pct = (float)$a['estimated_loss'] > 0 ? round($diff / (float)$a['estimated_loss'] * 100, 2) : null;

// Enviar respuesta
    out(200, 'Comparación consultada', ['period1' => $a, 'period2' => $b, 'difference' => $diff, 'percentage_change' => $pct, 'note' => 'Los valores económicos excluyen pérdidas sin costo estimable']);
} catch (Throwable $e) {
    failure($e);
}
