<?php
// Consulta el detalle de mermas y pérdidas.
require_once __DIR__ . '/common.php';
method('GET');
$u = user(false);
$id = positiveId($_GET['id'] ?? null);
try {
    $r = wasteOne($id);
    if (!$r) out(404, 'Merma no encontrada');
    if ($u['role'] === 'employee' && ((int)$r['user_id'] !== (int)$u['id'] || $r['waste_date'] !== date('Y-m-d'))) out(403, 'No tienes acceso a este registro');

// Enviar respuesta
    out(200, 'Detalle consultado', ['waste' => $r]);
} catch (Throwable $e) {
    failure($e);
}
