<?php
// Consulta la clasificación de mermas y pérdidas.
require_once __DIR__ . '/common.php';
method('GET');
user(true);
$d = wasteDates(['date_from', 'date_to']);
wasteRange($d['date_from'], $d['date_to']);
$where = ['w.waste_date BETWEEN ? AND ?'];
$params = [$d['date_from'], $d['date_to']];
if (isset($_GET['affected_type']) && $_GET['affected_type'] !== '') {
    if (!in_array($_GET['affected_type'], ['input', 'product', 'preparation'], true)) out(422, 'Tipo inválido');
    $where[] = 'w.affected_type=?';
    $params[] = $_GET['affected_type'];
}

// Consultar o preparar datos
$sql = "SELECT w.affected_type,w.input_id,w.product_id,w.preparation_id,COALESCE(i.name,p.name) AS affected_name,CASE WHEN w.affected_type='input' THEN i.unit ELSE NULL END AS affected_unit,COUNT(*) AS records,SUM(w.quantity) AS total_quantity,COALESCE(SUM(CASE WHEN w.cost_status='calculated' THEN w.estimated_total_cost ELSE 0 END),0) AS estimated_loss,SUM(CASE WHEN w.cost_status='unavailable' THEN 1 ELSE 0 END) AS without_cost FROM waste_records w LEFT JOIN inputs i ON i.id=w.input_id LEFT JOIN products p ON p.id=w.product_id WHERE " . implode(' AND ', $where) . ' GROUP BY w.affected_type,w.input_id,w.product_id,w.preparation_id,i.name,p.name,i.unit ORDER BY estimated_loss DESC,records DESC';
try {

// Enviar respuesta
    out(200, 'Ranking consultado', ['ranking' => rows($sql, $params), 'note' => 'Las cantidades solo se suman dentro de un mismo elemento; los costos no disponibles se reportan por separado']);
} catch (Throwable $e) {
    failure($e);
}
