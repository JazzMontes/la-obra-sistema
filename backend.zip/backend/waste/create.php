<?php
// Registra un nuevo mermas y pérdidas.
require_once __DIR__ . '/common.php';
method('POST');
$u = user(false);

// Recibir datos de la solicitud
$d = body();
$type = $d['affected_type'] ?? null;
if (!in_array($type, ['input', 'product', 'preparation'], true)) out(422, 'Tipo de elemento inválido');
if ($type === 'preparation') out(422, 'El servicio de preparaciones todavía no está disponible');
$id = positiveId($d['affected_id'] ?? null);
// Se admiten también input_id/product_id del esquema, pero sin IDs contradictorios.
foreach (['input_id', 'product_id', 'preparation_id'] as $field) if (isset($d[$field]) && $d[$field] !== null) {
    if ($field !== ($type === 'input' ? 'input_id' : 'product_id') || positiveId($d[$field]) !== $id) out(422, 'Identificador del elemento contradictorio');
}
$quantity = wasteAmount($d['quantity'] ?? null);
$approx = $d['is_approximate'] ?? false;
if (!is_bool($approx)) out(422, 'is_approximate debe ser booleano');
$date = dateval($d['waste_date'] ?? null);
$reason = $d['reason'] ?? null;
$class = $d['classification'] ?? null;
if (!is_string($reason) || trim($reason) === '' || mb_strlen($reason) > 500) out(422, 'Motivo obligatorio, máximo 500 caracteres');
if (!is_string($class) || trim($class) === '' || mb_strlen($class) > 100) out(422, 'Clasificación obligatoria, máximo 100 caracteres');
$table = $type === 'input' ? 'inputs' : 'products';
if (!record("SELECT id FROM $table WHERE id=?", [$id])) out(404, 'Elemento afectado no encontrado');
try {
    $pdo->beginTransaction();
    $cost = wasteUnitCost($type, $id);
    $total = $cost === null ? null : round($cost * (float)$quantity, 2);
    // Si excede la precisión decimal del esquema, registrar sin costo antes que inventar un valor.
    if ($total !== null && $total > 999999999999.99) {
        $cost = null;
        $total = null;
    }
    $s = $pdo->prepare('INSERT INTO waste_records(affected_type,input_id,product_id,preparation_id,quantity,is_approximate,waste_date,reason,classification,estimated_unit_cost,estimated_total_cost,cost_status,user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $s->execute([$type, $type === 'input' ? $id : null, $type === 'product' ? $id : null, null, $quantity, $approx ? 1 : 0, $date, trim($reason), trim($class), $cost, $total, $cost === null ? 'unavailable' : 'calculated', $u['id']]);
    $newId = (int)$pdo->lastInsertId();
    $pdo->commit();

// Enviar respuesta
    out(201, 'Merma registrada correctamente', ['waste' => wasteOne($newId)]);
} catch (Throwable $e) {
    failure($e);
}
