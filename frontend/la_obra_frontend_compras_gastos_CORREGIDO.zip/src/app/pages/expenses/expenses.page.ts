import {Component,ChangeDetectorRef} from '@angular/core';
import {Expenses} from '../../services/expenses';
import {Auth} from '../../services/auth';
@Component({selector:'app-expenses',templateUrl:'expenses.page.html',styleUrls:['expenses.page.scss'],standalone:false})
export class ExpensesPage {
 records:any[]=[];detail:any=null;history:any[]=[];loading=false;saving=false;modalOpen=false;detailOpen=false;historyOpen=false;message='';
 editingId:number|null=null;form:any={amount:null,reason:'',change_reason:''};status='';from='';to='';userId:any=null;
 isAdmin=false;
 constructor(private api:Expenses,private auth:Auth,private cdr:ChangeDetectorRef){this.isAdmin=this.auth.getStoredUser()?.role==='admin';}
 async ionViewWillEnter(){await this.load();}
 async load(){this.loading=true;try{const r=await this.api.list({status:this.status||undefined,date_from:this.from||undefined,date_to:this.to||undefined,user_id:this.isAdmin&&this.userId?this.userId:undefined});this.records=r.expenses||[];this.message='';}catch(e:any){this.message=e.response?.data?.message||'No se pudieron consultar los gastos';}finally{this.loading=false;this.cdr.detectChanges();}}
 openCreate(){this.editingId=null;this.form={amount:null,reason:'',change_reason:''};this.message='';this.modalOpen=true;}
 edit(e:any){if(e.status!=='active')return;this.editingId=+e.id;this.form={amount:+e.amount,reason:e.reason,change_reason:''};this.message='';this.modalOpen=true;}
 async show(e:any){try{this.detail=(await this.api.show(+e.id)).expense;this.detailOpen=true;}catch(x:any){this.message=x.response?.data?.message||'No se pudo consultar el gasto';}}
 async viewHistory(e:any){try{this.history=(await this.api.history(+e.id)).history||[];this.historyOpen=true;}catch(x:any){this.message=x.response?.data?.message||'No se pudo consultar el historial';}}
 async save(){if(this.saving)return;if(!(Number(this.form.amount)>0)||!String(this.form.reason||'').trim()||(this.editingId&&!String(this.form.change_reason||'').trim())){this.message='Completa monto, motivo y, si corriges, la razón del cambio';return;}this.saving=true;try{if(this.editingId)await this.api.update({id:this.editingId,amount:+this.form.amount,reason:this.form.reason.trim(),change_reason:this.form.change_reason.trim()});else await this.api.create({amount:+this.form.amount,reason:this.form.reason.trim()});this.modalOpen=false;await this.load();}catch(x:any){this.message=x.response?.data?.message||'No se pudo guardar';}finally{this.saving=false;this.cdr.detectChanges();}}
 async cancel(e:any){const reason=window.prompt('Escribe el motivo de cancelación del gasto #'+e.id);if(reason===null)return;if(!reason.trim()){this.message='El motivo de cancelación es obligatorio';return;}try{await this.api.cancel(+e.id,reason.trim());await this.load();}catch(x:any){this.message=x.response?.data?.message||'No se pudo cancelar el gasto';}}
}
