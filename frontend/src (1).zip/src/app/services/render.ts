// La app usa Angular sin zone.js ("zoneless"): Angular no se entera solo de que terminó
// una petición al servidor o de que Ionic mostró una pantalla, así que no repinta.
// Este servicio le avisa en esos momentos para que la vista se actualice en todas las pantallas.
import { ApplicationRef, Injectable } from '@angular/core';
import axios from 'axios';

@Injectable({ providedIn: 'root' })
export class RenderService {
  private pending = false;

  constructor(private appRef: ApplicationRef) {
    // Al terminar cualquier petición (correcta o con error)
    axios.interceptors.response.use(
      response => {
        this.schedule();
        return response;
      },
      error => {
        this.schedule();
        return Promise.reject(error);
      }
    );

    // Cuando Ionic entra o sale de una pantalla (ionViewWillEnter, ionViewDidEnter…)
    for (const evt of ['ionViewWillEnter', 'ionViewDidEnter', 'ionViewWillLeave']) {
      document.addEventListener(evt, () => this.schedule(), true);
    }

    // Cambios de conexión
    window.addEventListener('online', () => this.schedule());
    window.addEventListener('offline', () => this.schedule());
  }

  // Repinta después de que el código que esperaba la respuesta terminó de asignar los datos
  schedule() {
    if (this.pending) return;
    this.pending = true;
    setTimeout(() => {
      this.pending = false;
      this.appRef.tick();
    }, 0);
  }
}
