import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {IonicModule} from '@ionic/angular';
import {PurchasesPage} from './purchases.page';
import {PurchasesPageRoutingModule} from './purchases-routing.module';
@NgModule({imports:[CommonModule,FormsModule,IonicModule,PurchasesPageRoutingModule],declarations:[PurchasesPage]})
export class PurchasesPageModule{}
